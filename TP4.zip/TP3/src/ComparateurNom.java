import java.util.Comparator;

public class ComparateurNom implements Comparator<Hebergement> {

    @Override
    public int compare(Hebergement h1, Hebergement h2) {
        return h1.getNom().compareTo(h2.getNom());
    }
}