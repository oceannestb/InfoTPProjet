public class Main {
    public static void main(String[] args) {
        //creation hebergement
        Hebergement hotelAllain = new Chambre (101, "Hotel Allain Paris", "Hôtel", 85.0, 3) {
        };

        //création client
        AncienClient clientFidele = new AncienClient(
                "Allain", "Louise", "louise.allain@gmail.com",
                "15 rue de Paris", "loulou"
        );

        Reservation maResa = new Reservation(5001, clientFidele, hotelAllain);//nouvelle instauration de classe

        //test methodes de calcul
        int nuits = 3;
        double reduction = 0.10;
        double prixFinal = maResa.calculerPrixFinal(nuits, reduction);

        //afficher details
        System.out.println("       Récapitulatif de la Réservation     ");
        System.out.println("Client : " + clientFidele.getPrenom() + " " + clientFidele.getNom());
        System.out.println("Hébergement : " + hotelAllain.getNom());
        System.out.println("Nombre de nuits : " + nuits);
        System.out.println("Prix final : " + prixFinal + "€");

        //affichage statut
        maResa.changerStatut("confirmée");
        System.out.println("Statut actuel : " + maResa.getStatut());

        System.out.println("\n----- Test des constructeurs Chambre -----");

        // 1 objet avec constructeur par défaut
        Chambre chambre1 = new Chambre();

        // lecture clavier avec vérification
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        int numero;

        do {
            System.out.print("Entrez un numéro de chambre positif : ");
            numero = scanner.nextInt();
        } while (numero <= 0);

        // 2 objet avec constructeur paramétré
        Chambre chambre2 = new Chambre(102, "Hotel Allain Paris", "Hôtel", 90.0, numero);

        // 3 objet avec constructeur par copie
        Chambre chambre3 = new Chambre(chambre2);

        System.out.println("\n--- Affichage avec afficher() ---");

        chambre1.afficher();
        chambre2.afficher();
        chambre3.afficher();

        System.out.println("\n--- Affichage avec toString() ---");

        System.out.println(chambre1);
        System.out.println(chambre2);
        System.out.println(chambre3);

        CollectionHebergements collection = new CollectionHebergements();

        collection.ajouter(new Chambre(101,"Hotel Paris","Hôtel",85,3));
        collection.ajouter(new Chambre(102,"Hotel Lyon","Hôtel",60,2));
        collection.ajouter(new Chambre(103,"Hotel Nice","Hôtel",120,4));

        System.out.println("\nListe originale");
        collection.afficherTous();

// tri avec Comparable
        collection.trierParPrix();

        System.out.println("\nTri par prix");
        collection.afficherTous();

        Collections.sort(collection.getListe(), new ComparateurNom());

        System.out.println("\nTri par nom");
        collection.afficherTous();
    }
}