import java.util.List;

public abstract class Hebergement {

    private int id;
    private String nom;
    private String adresse;
    private String type;
    private double prixNuit;
    private List<String> equipements;

    public Hebergement(int id, String nom, String type, double prixNuit) {
        this.id = id;
        this.nom = nom;
        this.type = type;
        this.prixNuit = prixNuit;
    }

    public String getNom() {
        return nom;
    }

    public double getPrixNuit() {
        return prixNuit;
    }

    public boolean verifierDispo(String debut, String fin) {
        return true;
    }

    // méthode abstraite
    public abstract void afficher();

    // redéfinition de toString()
    @Override
    public String toString() {
        return "Hebergement : " + nom +
                " | Type : " + type +
                " | Prix par nuit : " + prixNuit + "€";
    }

    // comparaison par prix
    @Override
    public int compareTo(Hebergement h) {
        return Double.compare(this.prixNuit, h.prixNuit);
    }
}