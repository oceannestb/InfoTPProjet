public class Chambre extends Hebergement {

    private int numero;

    // constructeur par défaut
    public Chambre() {
        super(0, "Chambre standard", "Chambre", 50);
        this.numero = 0;
    }

    // constructeur avec paramètres
    public Chambre(int id, String nom, String type, double prixNuit, int numero) {
        super(id, nom, type, prixNuit);
        this.numero = numero;
    }

    // constructeur par copie
    public Chambre(Chambre c) {
        super(0, c.getNom(), "Chambre", c.getPrixNuit());
        this.numero = c.numero;
    }

    @Override
    public void afficher() {
        System.out.println("Chambre : " + getNom() + " | Numéro : " + numero);
    }

    @Override
    public String toString() {
        return super.toString() + " | Numéro : " + numero;
    }
}