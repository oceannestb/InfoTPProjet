import java.util.ArrayList;
import java.util.Collections;

public class CollectionHebergements {

    private ArrayList<Hebergement> liste;

    public CollectionHebergements() {
        liste = new ArrayList<>();
    }

    // ajouter un hébergement
    public void ajouter(Hebergement h) {
        liste.add(h);
    }

    // afficher tous les hébergements
    public void afficherTous() {
        for (Hebergement h : liste) {
            System.out.println(h);
        }
    }

    // tri avec Comparable
    public void trierParPrix() {
        Collections.sort(liste);
    }

    public ArrayList<Hebergement> getListe() {
        return liste;
    }
}