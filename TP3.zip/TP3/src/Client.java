import java.util.Date;

public class Client extends Personne {
    protected String motDePasse;
    protected Date dateInscription;

    public Client(String nom, String prenom, String email, String adresse, String mdp) {
        super(nom, prenom, email, adresse);
        this.motDePasse = mdp;
        this.dateInscription = new Date();
    }

    public void filtrerHebergement(String criteres) {
        System.out.println("Recherche en cours pour : " + criteres);
    }

    public void reserver() {
        System.out.println("Tentative de réservation...");
    }
}