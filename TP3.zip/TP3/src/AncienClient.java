import java.util.ArrayList;
import java.util.List;

public class AncienClient extends Client {
    private List<String> historiqueReservations;

    public AncienClient(String nom, String prenom, String email, String adresse, String mdp) {
        super(nom, prenom, email, adresse, mdp);
        this.historiqueReservations = new ArrayList<>();
    }

    public void seConnecter() {
        System.out.println("Connexion au compte de " + this.prenom);
    }
}
