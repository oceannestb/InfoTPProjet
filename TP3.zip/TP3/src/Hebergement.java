import java.util.List;

public class Hebergement {
    private int id;
    private String nom;
    private String adresse;
    private String type;
    private double prixNuit;
    private List<String> equipements;

    public Hebergement(int id, String nom, String type, double prixNuit) {
        this.id = id;
        this.nom = nom;
        this.type = type;
        this.prixNuit = prixNuit;
    }
    public String getNom() { return nom; }

    public boolean verifierDispo(String debut, String fin) {
        return true;
    }
}