public class Reservation {
    private int idReservation;
    private Client client;
    private Hebergement hebergement;
    private String statut; // "en attente", "confirmée"ou "annulée"

    public Reservation(int id, Client c, Hebergement h) {
        this.idReservation = id;
        this.client = c;
        this.hebergement = h;
        this.statut = "en attente";
    }

    public void changerStatut(String nouveauStatut) {
        this.statut = nouveauStatut;
    }

    public String getStatut() { return statut; }

    public double calculerPrixFinal(int nbNuits, double reductionPourcentage) {
        double prixTotal = nbNuits * 100.0;
        return prixTotal * (1 - reductionPourcentage);
    }
}