public class NouveauClient extends Client {
    public NouveauClient(String nom, String prenom, String email, String adresse, String mdp) {
        super(nom, prenom, email, adresse, mdp);
    }

    public void sInscrire() {
        System.out.println("Inscription: " + this.email);
    }
}