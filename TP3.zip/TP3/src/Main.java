public class Main {
    public static void main(String[] args) {
        //creation hebergement
        Hebergement hotelAllain = new Hebergement(101, "Hotel Allain Paris", "Hôtel", 85.0);

        //création client
        AncienClient clientFidele = new AncienClient(
                "Allain", "Louise", "louise.allain@gmail.com",
                "15 rue de Paris", "loulou"
        );

        Reservation maResa = new Reservation(5001, clientFidele, hotelAllain);//nouvelle instauration de classe

        //test methodes de calcul
        int nuits = 3;
        double reduction = 0.10;
        double prixFinal = maResa.calculerPrixFinal(nuits, reduction);

        //afficher details
        System.out.println("       Récapitulatif de la Réservation     ");
        System.out.println("Client : " + clientFidele.getPrenom() + " " + clientFidele.getNom());
        System.out.println("Hébergement : " + hotelAllain.getNom());
        System.out.println("Nombre de nuits : " + nuits);
        System.out.println("Prix final : " + prixFinal + "€");

        //affichage statut
        maResa.changerStatut("confirmée");
        System.out.println("Statut actuel : " + maResa.getStatut());
    }
}