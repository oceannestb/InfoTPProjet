public abstract class Personne {
    protected String nom;
    protected String prenom;
    protected String email;
    protected String adresse;

    public Personne(String nom, String prenom, String email, String adresse) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.adresse = adresse;
    }

    // pour recuperer les strings prenom et nom
    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
}